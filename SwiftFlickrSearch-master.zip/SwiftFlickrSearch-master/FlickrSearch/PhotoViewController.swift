//
//  PhotoViewController.swift
//  FlickrSearch
//
//  Created by Gaurav Kive on 5/14/18.
//  
//

import Foundation
enum tapInitiated: Int {
    case gameOver
}

class PhotoViewController: UIViewController {
    
    @IBOutlet weak var photoImageView: UIImageView!
    fileprivate var tapInitiator: tapInitiated?
    // Collection size
    var collectionCellSize: CGSize = {
        let size = (UIScreen.main.bounds.size.width-32)/3
        return CGSize(width: size, height: size)
    }()
    
    var flickrPhoto: FlickrPhoto?
    @IBOutlet var collectionView: UICollectionView?
    
    fileprivate var img: UIImage?
    fileprivate var arrImg = [UIImage]()
    fileprivate var imgIndex: Int?
    fileprivate var attemptCount: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView?.register(UINib(nibName: "FlickerCell", bundle: Bundle.main), forCellWithReuseIdentifier: "FlickerCell")

        var imgData: Data?
        if flickrPhoto != nil {
            photoImageView.sd_setImage(with: flickrPhoto!.photoUrl as URL!)
        }
        do{
            imgData = try Data(contentsOf: flickrPhoto!.photoUrl as URL!) 
        }
        catch
        {
            
        }
        
        if let imgTemp = imgData
        {
            img = UIImage(data: imgTemp)
            self.setImageArr(imgTemp: img!)
            
        }
        
        
    }
    
   private func setImageArr(imgTemp: UIImage)
    {
        imgIndex = Int(arc4random_uniform(UInt32(8)))
        print("image index\(String(describing: imgIndex))")
        for i in 0...7
        {
            if i == imgIndex
            {
                arrImg.append(imgTemp)
            }
            else
            {
                let img = UIImage(named: "img_Common.png")
                
                arrImg.append(img!)
            }
        }
        
        
        self.collectionView?.reloadData()
    }
    
    fileprivate func showAlert(msg: String)
    {
        let alert = UIAlertController(title: "Tap Info", message: msg, preferredStyle: UIAlertControllerStyle.alert)
        let sucessAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) { (UIAlertAction) in
            
            if self.tapInitiator == .gameOver
            {
                self.navigationController?.popViewController(animated: true)
            }
        }
        alert.addAction(sucessAction)
        self.navigationController?.present(alert, animated: true, completion: nil)
    }
    
}

//Mark: UICollectionView Datasource and delegate functions
extension PhotoViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
   internal func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrImg.count
    }
    
   internal func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionCellSize
    }
    
    internal func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlickerCell", for: indexPath) as? FlickerCell
        if arrImg.count >= indexPath.row
        {
          cell?.setImage(img: UIImage(named: "Question.png")!)
        }
        
        
        return cell!
    }
    
    internal func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        attemptCount += 1
        if attemptCount <= 4
        {
        let cell = collectionView.cellForItem(at: indexPath) as? FlickerCell
             if indexPath.row == imgIndex
             {
                
                cell?.setImageWithAnimation(imgToSet: self.img!)
                attemptCount = 5
                self.tapInitiator = .gameOver
                self.showAlert(msg: "Wow you did it.Please go back and initiate with a new image.")

             }
             else
             {
                
                cell?.setImageWithAnimation(imgToSet: UIImage(named: "img_Common.png")!)
                self.showAlert(msg: "Sorry This is wrong image.")
                
             }
        }
        else
        {
            self.tapInitiator = .gameOver
            self.showAlert(msg: "Game Over")
        }
       }
}

