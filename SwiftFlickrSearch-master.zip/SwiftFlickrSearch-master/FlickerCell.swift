//
//  FlickerCell.swift
//  FlickrSearch
//
//  Created by Gaurav Kive on 5/14/18.
//  
//

import UIKit

class FlickerCell: UICollectionViewCell {

   @IBOutlet private var imgMedia:   UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
     func setImage(img: UIImage)
    {
        self.imgMedia.image = img
    }
    
    func setImageWithAnimation(imgToSet: UIImage)
    {
    
        UIView.transition(with: (self.imgMedia)!, duration: 2, options: .transitionFlipFromRight, animations: nil, completion: { (true) in
            self.imgMedia.image = imgToSet
        })
    }
    
    

}
